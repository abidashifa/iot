
const connectBtn = document.getElementById("connectBtn");

let port;
let reader;
let keepReading = false;

// Connect ESP32
connectBtn.addEventListener("click", async () => {

    try {

        if (!("serial" in navigator)) {
            alert("Please use Google Chrome or Microsoft Edge.");
            return;
        }

        connectBtn.disabled = true;
        connectBtn.textContent = "Connecting...";

        port = await navigator.serial.requestPort();

        await port.open({
            baudRate: 115200
        });

        document.getElementById("connectionStatus").textContent =
            "Connected";

        document.getElementById("connectionStatus").style.color =
            "green";

        connectBtn.textContent = "Connected";

        keepReading = true;

        readData();

    } catch (error) {

        console.error(error);
        alert("Connection failed: " + error.message);
        connectBtn.disabled = false;
        connectBtn.textContent = "Connect ESP32";

    }

});


// Read ESP32 Serial Data
async function readData() {

    const decoder = new TextDecoder();
    let buffer = "";

    try {

        while (port.readable && keepReading) {

            reader = port.readable.getReader();

            try {

                while (true) {

                    const { value, done } = await reader.read();

                    if (done) break;

                    buffer += decoder.decode(value, {
                        stream: true
                    });

                    let lines = buffer.split("\n");

                    buffer = lines.pop();

                    for (let line of lines) {

                        line = line.trim();

                        if (line.length === 0) continue;

                        try {

                            const data = JSON.parse(line);

                            updateDashboard(data);

                        } catch (error) {

                            console.log("Invalid data:", line);

                        }

                    }

                }

            } finally {

                reader.releaseLock();

            }

        }

    } catch (error) {

        console.error("Serial reading error:", error);

    }

}


// Update dashboard values
function updateDashboard(data) {

    document.getElementById("gasAnalog").textContent =
        data.gasAnalog ?? "--";

    document.getElementById("gasDigital").textContent =
        data.gasDigital ?? "--";

    document.getElementById("fireValue").textContent =
        data.fireSensor ?? "--";

    document.getElementById("temperature").textContent =
        data.temperature ?? "--";

    document.getElementById("humidity").textContent =
        data.humidity ?? "--";


    // Gas status
    setStatus(
        "gasStatus",
        data.gasDetected,
        "Gas Detected",
        "Normal"
    );

    // Fire status
    setStatus(
        "fireStatus",
        data.fireDetected,
        "Fire Detected",
        "No Fire"
    );

    // Temperature status
    setStatus(
        "tempStatus",
        data.highTemp,
        "High Temperature",
        "Normal"
    );

    // Humidity display status
    const humidityElement =
        document.getElementById("humidityStatus");

    humidityElement.textContent =
        data.humidity === null ? "Sensor Error" : "Reading";

    humidityElement.className = "sensor-status";


    // Overall system status
    const statusCard =
        document.getElementById("statusCard");

    const systemStatus =
        document.getElementById("systemStatus");

    const warningMessage =
        document.getElementById("warningMessage");

    if (data.danger) {

        statusCard.classList.add("danger");

        systemStatus.textContent = "DANGER DETECTED";

        let warnings = [];

        if (data.gasDetected) warnings.push("Gas Detected");

        if (data.fireDetected) warnings.push("Fire Detected");

        if (data.highTemp) warnings.push("High Temperature");

        warningMessage.textContent = warnings.join(" | ");

    } else {

        statusCard.classList.remove("danger");

        systemStatus.textContent = "ENVIRONMENT NORMAL";

        warningMessage.textContent =
            "No danger detected.";

    }


    // Alert messages
    updateAlert("gasAlert", data.gasDetected,
        "Gas Detection");

    updateAlert("fireAlert", data.fireDetected,
        "Fire Detection");

    updateAlert("tempAlert", data.highTemp,
        "Temperature");


    // Last update time
    document.getElementById("lastUpdate").textContent =
        new Date().toLocaleTimeString();

}


// Update sensor status labels
function setStatus(id, danger, dangerText, normalText) {

    const element = document.getElementById(id);

    element.textContent = danger ? dangerText : normalText;

    element.className = danger
        ? "sensor-status danger"
        : "sensor-status";

}


// Update warning cards
function updateAlert(id, danger, name) {

    const element = document.getElementById(id);

    element.textContent = danger
        ? name + ": DANGER DETECTED"
        : name + ": Normal";

    element.className = danger
        ? "alert danger"
        : "alert normal";

}


// Disconnect handling
if ("serial" in navigator) {

    navigator.serial.addEventListener(
        "disconnect",
        () => {

            document.getElementById("connectionStatus").textContent =
                "Disconnected";

            document.getElementById("connectionStatus").style.color =
                "red";

            connectBtn.textContent = "Connect ESP32";
            connectBtn.disabled = false;

            keepReading = false;

        }
    );

}
